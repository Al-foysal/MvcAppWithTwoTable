﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace Class_07.Models
{
	
	
		public class Department
		{
			public Department()
			{
				this.Employees = new List<Employee>();
			}
			public int DepartmentId { get; set; }
			[Required, StringLength(50, MinimumLength = 3)]
			[Display(Name ="Department Name")]
			public string DepartmentName { get; set; }

			//Navigation
			public virtual ICollection<Employee> Employees { get; set; }
		}
		public class Employee
		{
			public int EmployeeId { get; set; }
			[Required, StringLength(50)]
			[Display(Name ="Employee Name")]
			public string EmployeeName { get; set; }
			[Required, Column(TypeName = "money")]
			[Display(Name = "Basic Salary")]
			public decimal BasicSalary { get; set; }
			//FK
			[Required]
			public int DepartmentId { get; set; }
			//Navigation
			[ForeignKey("DepartmentId")]
			public virtual Department Department { get; set; }
		}
		public class EmployeeDbContext : DbContext
		{
			public EmployeeDbContext()
			{
				Database.SetInitializer(new DbInitializer());
			}
			public DbSet<Department> Departments { get; set; }
			public DbSet<Employee> Employees { get; set; }
		}
		public class DbInitializer : DropCreateDatabaseIfModelChanges<EmployeeDbContext>
		{
			protected override void Seed(EmployeeDbContext context)
			{
				Department d = new Department { DepartmentName = "Admin" };
				d.Employees.Add(new Employee { EmployeeName = "A1", BasicSalary = 2000.00M });
				d.Employees.Add(new Employee { EmployeeName = "A2", BasicSalary = 2000.00M });
				context.Departments.Add(d);
				context.SaveChanges();
			}
	    }
}	
