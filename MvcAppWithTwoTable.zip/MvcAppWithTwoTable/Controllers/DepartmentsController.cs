﻿using Class_07.Models;
using PagedList;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Class_07.Controllers
{
    public class DepartmentsController : Controller
    {
		EmployeeDbContext db = new EmployeeDbContext();
		// GET: Departments
		public ActionResult Index(int page=1)
        {
			int perPage = 5;
			var data = db.Departments
				.OrderBy(x => x.DepartmentId)
				.Skip((page - 1) * perPage)
				.Take(perPage)
				.ToList();
			ViewBag.CurrentPage = page;
			ViewBag.TotalPages = (int)Math.Ceiling((double)db.Departments.Count() / perPage);
            return View(data);
        }
		public ActionResult IndexedPage(int page = 1)
		{
			int perPage = 5;
			var data = db
			.Departments
			.OrderBy(x => x.DepartmentId)
			.ToPagedList(page, perPage);
			return View(data);
		}
		public ActionResult Create()
		{
			return View();
		}
		[HttpPost]
		public ActionResult Create(Department dept)
		{
			if (ModelState.IsValid)
			{
				db.Departments.Add(dept);
				db.SaveChanges();
				return RedirectToAction("Index");
			}
			return View(dept);
		}
		public ActionResult Edit(int id)
		{
			var dept = db.Departments.First(x => x.DepartmentId == id);
			return View(dept);
		}
		[HttpPost]
		public ActionResult Edit(Department dept)
		{
			if (ModelState.IsValid)
			{
				db.Entry(dept).State = System.Data.Entity.EntityState.Modified;
				db.SaveChanges();
				return RedirectToAction("Index");
			}
			return View(dept);
		}
		public ActionResult Delete(int id)
		{
			var dept = db.Departments.First(x => x.DepartmentId == id);
			return View(dept);
		}
		[HttpPost, ActionName("Delete")]
		public ActionResult DeleteConfirm(int id)
		{
			var dept = new Department { DepartmentId = id };
			db.Entry(dept).State = System.Data.Entity.EntityState.Deleted;
			db.SaveChanges();
			return RedirectToAction("Index");
		}

	}
}