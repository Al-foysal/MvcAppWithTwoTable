﻿using Class_07.Models;
using PagedList;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using System.Web.Mvc;

namespace Class_07.Controllers
{
    public class EmployeesController : Controller
    {
		EmployeeDbContext db = new EmployeeDbContext();
        // GET: Employees
        public ActionResult Index(int page=1)
        {
			var data = db
				.Employees
				.Include( emp => emp.Department)
				.OrderBy(x=> x.EmployeeId)
				.ToPagedList(page, 5);
			return View(data);
        }
		public ActionResult Create()
		{
			ViewBag.Departments = db.Departments.ToList();
			return View();
		}
		[HttpPost]
		public ActionResult Create(Employee emp)
		{
			if (ModelState.IsValid)
			{
				db.Employees.Add(emp);
				db.SaveChanges();
				return RedirectToAction("Index");
			}
			ViewBag.Departments = db.Departments.ToList();
			return View(emp);
		}
		public ActionResult Edit(int id)
		{
			var emp = db.Employees.First(x => x.EmployeeId == id);
			return View(emp);
		}
		[HttpPost]
		public ActionResult Edit(Employee emp)
		{
			if (ModelState.IsValid)
			{
				db.Entry(emp).State = System.Data.Entity.EntityState.Modified;
				db.SaveChanges();
				return RedirectToAction("Index");
			}
			return View(emp);
		}
		public ActionResult Delete(int id)
		{
			var emp = db.Employees.First(x => x.EmployeeId == id);
			return View(emp);
		}
		[HttpPost, ActionName("Delete")]
		public ActionResult DeleteConfirm(int id)
		{
			var emp = new Employee { EmployeeId = id };
			db.Entry(emp).State = System.Data.Entity.EntityState.Deleted;
			db.SaveChanges();
			return RedirectToAction("Index");
		}
	}
}